import Image from "next/image"
import { CheckCircle2 } from "lucide-react"

const highlights = [
  "ISO 9001:2015 & C-TPAT certified operations",
  "Proprietary AI-driven route optimization engine",
  "Carbon-neutral shipping options available",
  "Dedicated account managers for enterprise clients",
]

export function About() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-muted/20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid items-center gap-16 lg:grid-cols-2">
          <div className="relative">
            <div className="overflow-hidden rounded-2xl border border-border">
              <Image
                src="/images/fleet.jpg"
                alt="Fleet of modern trucks at a logistics yard during golden hour"
                width={600}
                height={450}
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 hidden rounded-xl border border-border bg-card p-6 shadow-xl lg:block">
              <p className="text-3xl font-bold text-accent font-mono">28+</p>
              <p className="text-sm text-muted-foreground">Years of excellence</p>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            <p className="text-sm font-semibold uppercase tracking-widest text-accent">
              Why Apex
            </p>
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
              Built for enterprises that move the world
            </h2>
            <p className="text-lg leading-relaxed text-muted-foreground">
              Since 1997, Apex Logistics has been the trusted partner for
              Fortune 500 companies requiring reliable, scalable freight and
              supply chain management. Our technology-first approach ensures
              complete visibility from pickup to delivery.
            </p>

            <div className="flex flex-col gap-4 mt-2">
              {highlights.map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
                  <span className="text-sm text-foreground">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
