import { Button } from "@/components/ui/button"
import { ArrowRight, Phone } from "lucide-react"

export function CTA() {
  return (
    <section id="contact" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="relative overflow-hidden rounded-2xl border border-border bg-card p-12 lg:p-20">
          <div className="absolute -top-24 -right-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-accent/10 blur-3xl" />

          <div className="relative mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-card-foreground sm:text-4xl text-balance">
              Ready to optimize your supply chain?
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Get a custom quote in under 24 hours. Our logistics experts will
              design a solution tailored to your business needs.
            </p>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold gap-2 px-8"
              >
                Request a Quote
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-border text-card-foreground hover:bg-muted gap-2"
              >
                <Phone className="h-4 w-4" />
                Call 1-800-APEX
              </Button>
            </div>

            <p className="mt-6 text-xs text-muted-foreground">
              No commitment required. Free consultation for enterprise accounts.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
