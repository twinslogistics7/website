import Link from "next/link"
import { Package } from "lucide-react"

const footerLinks = {
  Solutions: ["Freight Forwarding", "Warehousing", "Ocean Freight", "Air Freight", "Express Delivery"],
  Company: ["About Us", "Careers", "Press", "Partners", "Sustainability"],
  Resources: ["Blog", "Case Studies", "API Docs", "Help Center", "Status"],
  Legal: ["Privacy Policy", "Terms of Service", "Cookie Policy", "Compliance"],
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/10">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-6">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Package className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold tracking-tight text-foreground font-mono">
                APEX
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Global logistics and supply chain solutions trusted by enterprises
              since 1997. Moving the world forward, one shipment at a time.
            </p>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <p className="text-sm font-semibold text-foreground">{category}</p>
              <ul className="mt-4 flex flex-col gap-2.5">
                {links.map((link) => (
                  <li key={link}>
                    <Link
                      href="#"
                      className="text-sm text-muted-foreground transition-colors hover:text-accent"
                    >
                      {link}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 md:flex-row">
          <p className="text-xs text-muted-foreground">
            2026 Apex Logistics. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link href="#" className="text-xs text-muted-foreground hover:text-accent">
              Privacy
            </Link>
            <Link href="#" className="text-xs text-muted-foreground hover:text-accent">
              Terms
            </Link>
            <Link href="#" className="text-xs text-muted-foreground hover:text-accent">
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
