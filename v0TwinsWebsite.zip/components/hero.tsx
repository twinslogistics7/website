import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, Play } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-20">
      <div className="absolute inset-0">
        <Image
          src="/images/hero-logistics.jpg"
          alt="Aerial view of a logistics hub at dusk with shipping containers"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-background/85" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_oklch(0.45_0.18_300_/_0.15),_transparent_60%)]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 py-24 md:py-32">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="flex flex-col gap-8">
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/50 px-4 py-1.5 text-xs font-medium text-accent w-fit">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" />
              Trusted by 2,000+ enterprises worldwide
            </div>

            <h1 className="text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl lg:text-6xl text-balance">
              Global logistics,{" "}
              <span className="text-accent">delivered</span> with precision
            </h1>

            <p className="max-w-lg text-lg leading-relaxed text-muted-foreground">
              End-to-end freight management, warehousing, and supply chain
              solutions across 150+ countries. Move faster. Ship smarter.
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold gap-2 px-8"
              >
                Start Shipping
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-border text-foreground hover:bg-muted gap-2"
              >
                <Play className="h-4 w-4" />
                Watch Demo
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div>
                <p className="text-2xl font-bold text-accent font-mono">150+</p>
                <p className="text-xs text-muted-foreground">Countries</p>
              </div>
              <div className="h-8 w-px bg-border" />
              <div>
                <p className="text-2xl font-bold text-accent font-mono">99.8%</p>
                <p className="text-xs text-muted-foreground">On-Time Rate</p>
              </div>
              <div className="h-8 w-px bg-border" />
              <div>
                <p className="text-2xl font-bold text-accent font-mono">24/7</p>
                <p className="text-xs text-muted-foreground">Live Support</p>
              </div>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="relative overflow-hidden rounded-2xl border border-border shadow-2xl shadow-primary/20">
              <Image
                src="/images/warehouse.jpg"
                alt="Inside a modern automated warehouse facility"
                width={600}
                height={450}
                className="w-full h-auto object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-6">
                <div className="flex items-center gap-3">
                  <div className="h-3 w-3 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-sm font-medium text-foreground">
                    Live: 12,847 packages in transit
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
