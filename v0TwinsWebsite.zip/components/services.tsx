import { Truck, Warehouse, Globe, BarChart3, Shield, Clock } from "lucide-react"

const services = [
  {
    icon: Truck,
    title: "Freight Forwarding",
    description:
      "Full truckload, LTL, and intermodal solutions with real-time tracking across North America, Europe, and Asia-Pacific.",
  },
  {
    icon: Warehouse,
    title: "Warehousing & Fulfillment",
    description:
      "State-of-the-art facilities with automated inventory management, pick-and-pack, and same-day dispatch capabilities.",
  },
  {
    icon: Globe,
    title: "International Shipping",
    description:
      "Ocean and air freight to 150+ countries with full customs brokerage, documentation, and compliance support.",
  },
  {
    icon: BarChart3,
    title: "Supply Chain Analytics",
    description:
      "AI-powered visibility platform providing real-time insights, predictive analytics, and cost optimization.",
  },
  {
    icon: Shield,
    title: "Cargo Insurance",
    description:
      "Comprehensive coverage options for all freight types with streamlined claims processing and rapid payouts.",
  },
  {
    icon: Clock,
    title: "Express & Last Mile",
    description:
      "Time-critical and white-glove delivery services with guaranteed SLAs and proof-of-delivery documentation.",
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-accent">
            Our Services
          </p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
            Comprehensive logistics solutions
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            From origin to destination, we manage every link in your supply
            chain with precision and care.
          </p>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <div
              key={service.title}
              className="group rounded-xl border border-border bg-card p-8 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <service.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-card-foreground">
                {service.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
