const stats = [
  { value: "2M+", label: "Shipments per year", description: "across all modes" },
  { value: "$4.2B", label: "Freight managed", description: "annual volume" },
  { value: "98.6%", label: "Customer retention", description: "year over year" },
  { value: "35min", label: "Avg. response time", description: "customer support" },
]

export function StatsBar() {
  return (
    <section className="border-y border-border bg-muted/30">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-3xl font-bold text-accent font-mono lg:text-4xl">
                {stat.value}
              </p>
              <p className="mt-1 text-sm font-medium text-foreground">
                {stat.label}
              </p>
              <p className="text-xs text-muted-foreground">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
