import { Star } from "lucide-react"

const testimonials = [
  {
    quote:
      "Apex reduced our shipping costs by 23% while improving delivery times. Their analytics platform gives us visibility we never had before.",
    author: "Sarah Chen",
    role: "VP of Operations",
    company: "TechNova Inc.",
  },
  {
    quote:
      "We switched to Apex for our international freight and haven't looked back. Their customs brokerage team is phenomenal.",
    author: "Marcus Williams",
    role: "Supply Chain Director",
    company: "GreenLeaf Consumer Goods",
  },
  {
    quote:
      "The dedicated account management and 24/7 support have made Apex an indispensable partner for our e-commerce fulfillment.",
    author: "Priya Sharma",
    role: "Head of Logistics",
    company: "Meridian Retail Group",
  },
]

export function Testimonials() {
  return (
    <section className="py-24 lg:py-32 bg-muted/20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-accent">
            Testimonials
          </p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
            Trusted by industry leaders
          </h2>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <div
              key={t.author}
              className="flex flex-col justify-between rounded-xl border border-border bg-card p-8"
            >
              <div>
                <div className="flex gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-accent text-accent"
                    />
                  ))}
                </div>
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
                  {`"${t.quote}"`}
                </p>
              </div>
              <div className="mt-6 border-t border-border pt-5">
                <p className="text-sm font-semibold text-card-foreground">{t.author}</p>
                <p className="text-xs text-muted-foreground">
                  {t.role}, {t.company}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
