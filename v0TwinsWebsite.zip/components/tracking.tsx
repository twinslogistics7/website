"use client"

import { useState } from "react"
import { Search, MapPin, Package, Clock, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const sampleSteps = [
  { status: "Picked Up", location: "Shanghai, CN", time: "Feb 22, 10:15 AM", complete: true },
  { status: "In Transit", location: "Hong Kong, HK", time: "Feb 23, 3:42 PM", complete: true },
  { status: "Customs Cleared", location: "Los Angeles, US", time: "Feb 25, 8:20 AM", complete: true },
  { status: "Out for Delivery", location: "Dallas, TX", time: "Feb 26, 11:05 AM", complete: false },
]

export function Tracking() {
  const [trackingId, setTrackingId] = useState("")
  const [showResult, setShowResult] = useState(false)

  return (
    <section id="tracking" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-accent">
            Track & Trace
          </p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
            Real-time shipment visibility
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            Enter your tracking ID to get instant updates on your shipment
            status, location, and estimated delivery time.
          </p>
        </div>

        <div className="mx-auto mt-12 max-w-xl">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Enter tracking ID (e.g. APX-2026-84721)"
                className="h-12 pl-10 bg-card border-border text-foreground placeholder:text-muted-foreground"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
              />
            </div>
            <Button
              className="h-12 bg-accent text-accent-foreground hover:bg-accent/90 px-6 font-semibold"
              onClick={() => setShowResult(true)}
            >
              Track
            </Button>
          </div>

          {showResult && (
            <div className="mt-8 rounded-xl border border-border bg-card p-6">
              <div className="flex items-center justify-between border-b border-border pb-4">
                <div>
                  <p className="text-sm text-muted-foreground">Tracking ID</p>
                  <p className="font-mono font-semibold text-foreground">
                    APX-2026-84721
                  </p>
                </div>
                <div className="rounded-full bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
                  In Transit
                </div>
              </div>

              <div className="mt-6 flex flex-col gap-6">
                {sampleSteps.map((step, i) => (
                  <div key={step.status} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div
                        className={`flex h-8 w-8 items-center justify-center rounded-full ${
                          step.complete
                            ? "bg-accent text-accent-foreground"
                            : "border-2 border-primary bg-card text-primary"
                        }`}
                      >
                        {step.complete ? (
                          <CheckCircle2 className="h-4 w-4" />
                        ) : (
                          <Package className="h-4 w-4" />
                        )}
                      </div>
                      {i < sampleSteps.length - 1 && (
                        <div
                          className={`mt-1 h-full w-0.5 ${
                            step.complete ? "bg-accent" : "bg-border"
                          }`}
                        />
                      )}
                    </div>
                    <div className="pb-6">
                      <p className="font-medium text-card-foreground">{step.status}</p>
                      <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {step.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {step.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
